<?php
include 'database.php';
//admin login function
function adminLogin($userName, $password)
{
    $login = [];
    $conn = connect();
    $sql = "SELECT * FROM staff WHERE userName = ?";
    $stm = $conn->prepare($sql);
    $stm->bind_param("s", $userName);
    $stm->execute();
    $result = $stm->get_result();
    $stm->close();
    //check if username is valid:
    if ($result->num_rows === 1) {
        while ($rows = $result->fetch_assoc()) {
            //if username is valid, then check the password:
            if (password_verify($password, $rows['password']) === TRUE) {
                $login['userName'] = $rows['userName'];
                $login['userRole'] = $rows['roleID'];
            } else {
                $login['error'] = "Invalid username or password";
            }
        }
    } else {
        $login['error'] = "Invalid username or password";
    }
    return $login;
}

function admin_AddProduct($name, $price, $detail, $category, $quantity, $imgURL)
{
    $conn = connect();
    //find catergoryID:
    $sql = "SELECT categoryID FROM category WHERE categoryName = '$category'";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $categoryID = $row['categoryID'];
    }
    //Check if product name exist:
    $checkPName = $conn->query("SELECT productName FROM product WHERE productName = '$name'");
    if ($checkPName->num_rows > 0) {
        $error = "The product name has already existed in the database.";
        return $error;
    } else {
        //insert product:
        $sql = "CALL addProduct('$name', '$price', '$detail', '$categoryID', '$quantity')";
        $conn->query($sql);
        //upload avatar:
        $findPID = $conn->query("SELECT MAX(productID) as 'max' FROM product");
        while ($row = $findPID->fetch_assoc()) {
            $pID = $row['max'];
        }
        $sql = "INSERT INTO image(productID, imgType, imgURL) values ('$pID', 1, '$imgURL')";
        $conn->query($sql);
    }
    $conn->close();
}

function admin_removeProduct($pid)
{
    $conn = connect();
    $sql = "DELETE FROM product WHERE productID = '$pid'";
    $conn->query($sql);
    $conn->close();
}

function admin_displayProduct($search)
{
    $conn = connect();
    $sql = "SELECT img.imgURL, pd.productID, pd.productName, ct.categoryName, pd.productDetail, pd.unitPrice, pd.stock 
    FROM product as pd 
    INNER JOIN category as ct ON pd.categoryID = ct.categoryID 
    INNER JOIN image as img ON pd.productID = img.productID
    WHERE pd.productName LIKE CONCAT('%', '$search', '%')
    ORDER by ct.categoryName
    ";
    $list = $conn->query($sql);
    if ($list->num_rows > 0) {
        echo "<table class='tbl table table-striped table-hover'>
                <tr class='head'>
                    <th>Image</th>
                    <th>Product Name</th>
                    <th>Category</th>
                    <th>Product detail</th>
                    <th>Unit price</th>
                    <th>In stock</th>
                    <th colspan='2'>Manage</th>
                    
                </tr>
            ";
        while ($item = $list->fetch_assoc()) { ?>
            <tr>
                <td><img src="..\\<?= $item['imgURL'] ?>" alt="image" style="width:50px; height:50px;"></td>
                <td><?= $item['productName'] ?></td>
                <td style=''><?= $item['categoryName'] ?></td>
                <td style='text-align:justify;'><?= $item['productDetail'] ?></td>
                <td style='text-align:right;'>$<?= $item['unitPrice'] ?></td>
                <td><?= $item['stock'] ?></td>
                <!-- <td class='edit'><a class="item-list btn btn-success" href="manageproduct.php?id=<?= $item['productID'] ?>">Manage</a></td> -->
                <td class="edit"><button class="item-list btn btn-success edit-product" data-bs-toggle="modal" data-id="<?= $item['productID'] ?>" data-bs-target="#editPanel">Update</button></td>
                <td class='edit'><a class="item-list btn btn-danger" href="removeproduct.php?id=<?= $item['productID'] ?>" onclick="return confirm('Do you want to remove this product? This action can not be undone!');">Remove</a></td>
            </tr>

<?php   }
        echo "</table>";
    } else {
        echo "<table class='table'><tr><td><b>Product not found.</b></td></tr></table>";
    }
}
?>
<?php
function admin_input($product, $value)
{
    $conn = connect();
    if ($value < 0) {
        $error = 'You can not enter negative value.';
        return $error;
    } else if (preg_match('/^[0-9]*$/', $value)) {
        $error = 'You must enter digit number only.';
        return $error;
    } else {
        //find product ID:
        $findPID = $conn->query("SELECT productID FROM product WHERE productName = '$product'");
        while ($row = $findPID->fetch_assoc()) {
            $pID = $row['productID'];
        }
        $sql = "CALL inputStock('$pID', '$value')";
        $conn->query($sql);
    }
    $conn->close();
}
function admin_updateProduct($pname, $price, $category, $detail, $imgURL)
{
    $conn = connect();
    if ($price < 0) {
        $error = 'You can not enter negative value.';
        return $error;
    } else if (preg_match('/^[-+]?[0-9]*\.?[0-9]+$/', $price)) { //match float number
        $error = 'You must enter digit number only.';
        return $error;
    } else {
        //find cID:
        $sql_findcID = "SELECT categoryID FROM category WHERE categoryName = '$category'";
        $result = $conn->query($sql_findcID);
        while ($row = $result->fetch_assoc()){
            $cID = $row['categoryID'];
        }

        //find pID:
        $sql_findpID = "SELECT productID FROM product WHERE productName = '$pname'";
        $result = $conn->query($sql_findpID);
        while ($row = $result->fetch_assoc()){
            $pID = $row['productID'];
        }

        $pname = $conn->real_escape_string($pname);
        $price = $conn->real_escape_string($price);
        $detail = $conn->real_escape_string($detail);

        //update product infomation:
        $sql = "UPDATE product SET productName = '$pname', unitPrice = '$price', categoryID = '$cID', productDetail = '$detail' WHERE productID = '$pID'";
        
        //update image URL:
        if(!empty($imgURL)) {
            $sql = "UPDATE image SET imgURL = '$imgURL' WHERE productID = '$pID'";
            $conn->query($sql);
        }

    }
}