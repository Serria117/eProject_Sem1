<?php
session_start();
require 'adminFunction.php';
if (isset($_SESSION['userRole']) && $_SESSION['userRole'] == 1) {
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin CP</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="..//css//adminCP.css">
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', () => {
                if (window.history.replaceState) {
                    window.history.replaceState(null, null, location.href);
                }

                //Refocus on the 1st input box after reset the form
                document.querySelector('#reset').onclick = () => {
                    document.querySelector('input').focus();
                }
                //Validate category, a provided category must be selected before submitting new product
                var ctg = document.querySelector('#ctg');
                document.querySelector('#addproduct').onsubmit = (event) => {
                    if (ctg.value === 'select:') {
                        event.preventDefault();
                        alert('You must specify a category for the product.');
                        ctg.focus();
                    }
                }
                //Validate price (decimal number, greater than zero) before submitting new product
                var price = document.querySelector('#price');
                var priceCheck = /^[-+]?[0-9]*\.?[0-9]+$/;
                price.onblur = () => {
                    if (price.value.length > 0) {
                        if (priceCheck.test(price.value) === false || price.value < 0) {
                            alert('You must enter positive decimal number for unit price.');
                            price.value = '';
                            price.focus();
                        }
                    }
                }
                //Validate quantity (integer number, greate than zero) before submitting new product
                var quantity = document.querySelector('#quantity');
                var quantityCheck = /^[0-9]*$/;
                quantity.onblur = () => {
                    if (quantity.value.length > 0) {
                        if (quantityCheck.test(quantity.value) === false) {
                            alert('You must enter positive integer number for initial quantity.');
                            quantity.value = '';
                            quantity.focus();
                        }
                    }
                }
            });

            // jquery ajax function
            $(document).ready(function() {
                //get product detail for edit:
                $('.edit-product').click(function() {
                    var productID = $(this).attr("data-id"); //get the value of the attribute 'data-id' from the button when click
                    $.ajax({
                        url: "query.php",
                        method: "post",
                        data: {
                            product: productID
                        }, //the request name is 'Product' and the value to be sent is the variable 'productID'
                        success: function(data) { //with the data get from server, insert into the div id 'product-detail' and show the modal
                            $('#product-detail').html(data);
                        }
                    })
                })
            });
        </script>
    </head>

    <body>
        <div class="container-fluid">
            <div class="sidebar">
                <div class="sidebar-header">
                    <h4><i class="fa fa-star-o icon" aria-hidden="true"></i>STAR ORGANIC</h4>
                </div>
                <ul class="menu">
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-home" aria-hidden="true"></i></span>
                            <span class="text">Home</span>
                        </li>
                    </a>
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-th-list" aria-hidden="true"></i></span>
                            <span class="text">Manage Order</span>
                        </li>
                    </a>
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-product-hunt" aria-hidden="true"></i></span>
                            <span class="text">Manage Product</span>
                        </li>
                    </a>
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-folder-open" aria-hidden="true"></i></span>
                            <span class="text">Manage Category</span>
                        </li>
                    </a>
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-user" aria-hidden="true"></i></span>
                            <span class="text">Manage User</span>
                        </li>
                    </a>
                    <a href="">
                        <li>
                            <span class="icon"><i class="fa fa-users" aria-hidden="true"></i></span>
                            <span class="text"></span>Manage Customer</span>
                        </li>
                    </a>
                    <a href="logout.php" onclick="return confirm('Do you want to log out?')">
                        <li class="logout">
                            <span class="icon"><i class="fa fa-power-off" aria-hidden="true"></i></span>
                            <span class="text">LOG OUT</span>
                        </li>
                    </a>
                </ul>
            </div>

            <div class="content">
                <h2>Product Management</h2>
                <div class="product add">
                    <h4>Add new product</h4>
                    <form id="addproduct" action="addProduct.php" method="post" enctype="multipart/form-data">
                        <div class="input-group mb-1">
                            <span class="input-group-text">Product name:</span>
                            <input type="text" id="pname" class="form-control" name="pname" placeholder="" aria-label="pname" required>
                            <span class="input-group-text">Category:</span>
                            <select class="form-select" name="category" id="ctg">
                                <option value="select:">select:</option>
                                <?php
                                $conn = connect();
                                $list = $conn->query("SELECT categoryName FROM category");
                                if ($list->num_rows > 0) {
                                    while ($item = $list->fetch_assoc()) {
                                        echo "<option value=\"{$item['categoryName']}\">{$item['categoryName']}</option>";
                                    }
                                }
                                $conn->close();
                                ?>
                            </select>
                            
                            <button type="button" class="form-control btn btn-warning">
                                <i class="fa fa-folder-open" aria-hidden="true"></i>
                                New Category
                            </button>
                            <!-- <input type="button" value="New Category" class="form-control btn btn-secondary"> -->
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text">Unit price:</span>
                            <span class="input-group-text"><i class="fa fa-usd" aria-hidden="true"></i></span>
                            <input type="text" id="price" class="form-control" name="price" placeholder="" aria-label="price" required>
                            <span class="input-group-text">Quantity:</span>
                            <input id="quantity" type="text" class="form-control" name="quantity" placeholder="" aria-label="quantity" required>
                        </div>
                        <div class="form-floating mb-3">
                            <!-- <span class="input-group-text">Description:</span> -->
                            <textarea id="detail" style="height: 100px" class="form-control" name="detail" aria-label="detail" required></textarea>
                            <label for="detail">Product detail</label>
                        </div>
                        <!-- image upload -->
                        <h6></h6>
                        <div class="mb-3">
                            <label for="customFile">Avatar image:</label>
                            <input type="file" class="form-control" id="customFile" name="avatar" />
                            <small id="imgHelp" class="form-text text-muted">Accept only JPG, PNG and GIF image files.</small>
                        </div>

                        <!-- submit -->
                        <div class="submit input-group mb3">
                            <input class="btn-add btn btn-primary" type="submit" value="Add" name="add" id="add">
                            <button class="btn-add btn btn-danger" type="reset" id="reset">Reset</button>
                        </div>
                    </form>
                </div>
                <hr>
                <div class="product list">
                    <div class="title">
                        <h4>Product list</h4>
                    </div>
                    <form action="" method="post">
                        <div class="search-bar input-group">
                            <input name="searchvalue" type="search" id="form1" class="form-control" placeholder="Search" />
                            <button class="btn btn-outline-success" type="submit" name="search">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </button>
                        </div>
                    </form>
                    <div class="display">
                        <!-- display product list from database -->
                        <?php
                        if (isset($_POST['search'])) {
                            admin_displayProduct($_POST['searchvalue']);
                        } else {
                            admin_displayProduct('');
                        }
                        ?>
                    </div>
                </div>
                <!-- Update product -->
                <form id='mng-product' action='updateproduct.php' method='post' enctype='multipart/form-data'>
                    <div class="modal fade" id="editPanel" tabindex="-1" aria-labelledby="editPanelLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="editPanelLabel">Update Product</h4>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body" id="product-detail">
                                <!-- query.php fetch data here -->
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <input type="submit" value="Save changes" name="save" class="btn btn-primary">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- display message -->
        <?php
        if (isset($_SESSION['error'])) {
            echo "<script>alert('{$_SESSION['error']}')</script>";
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo "<script>alert('{$_SESSION['success']}')</script>";
            unset($_SESSION['success']);
        }
        ?>
    </body>
    </html>
<?php
} else {
    header("location: index.php");
}
?>