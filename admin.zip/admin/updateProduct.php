<?php
session_start();
require 'adminFunction.php';
if(isset($_POST['save'])){
    $conn = connect();
    $pname = $_POST['pname'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $detail = $_POST['detail'];
    

    echo $pname .'<br>';
    echo $category.'<br>';
    echo $price.'<br>';
    exit();

    $_SESSION['success'] = 'Product updated successfully';
    header ("location: admin_panel.php");
}
?>